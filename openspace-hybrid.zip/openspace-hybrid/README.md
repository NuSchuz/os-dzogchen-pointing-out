# OpenSpace · Living Atmosphere + Space, Time, Knowing

This package is an additive enhancement for the **existing V8** OpenSpace app at https://nuschuz.github.io/os-dzogchen-pointing-out/.

**No original module code is modified.** It provides a low-resolution procedural WebGL atmospheric backdrop with slow fBm cloud-like color fields; a pause control; and a sixth original nine-step inquiry inspired by Tarthang Tulku's *Time, Space, Knowledge*. It does not purport to quote Tulku.

## Install

Copy `openspace-atmosphere.css` and `openspace-atmosphere.js` to the same folder as your existing `index.html`.

Insert before `</head>`:

    <link rel="stylesheet" href="./openspace-atmosphere.css">

Insert before `</body>`, **after the existing application's inline JS**:

    <script src="./openspace-atmosphere.js" defer></script>

Do **not** install the older V9 refresh files alongside this package.

## Important limits

The live source could not be downloaded into this environment for end-to-end testing, so this is an integration candidate, **not a verified deployment**. The enhancement targets V8 DOM identifiers inspected in the earlier app work. It intentionally leaves existing event handlers and mode arrays untouched. The original content and controls are hidden only while the new sixth module is selected, and restored on selecting any of the existing five. WebGL failure leaves a static gradient instead of an empty page.

## Remove

Remove the two includes from index.html; no original data was changed.
